const express= require("express");
const https = require("https");
const bodyparser =  require("body-parser");
const { response } = require("express");
const app = express();
app.use(bodyparser.urlencoded({extended:true}));

app.get("/",function(req,res){
        console.log("Server is up and running");
        res.sendFile(__dirname+"/index.html");
});

app.post("/",function(req,res)

{ 
  var query = req.body.city;
  var apikey="4ccadd68e4dcf103b16308393b832dcc";
  const url="https://api.openweathermap.org/data/2.5/weather?q="+query+"&appid="+apikey;
  https.get(url,function(response){
        response.on("data",function(data){
                var weatherData = JSON.parse(data);
                var temp = weatherData.main.temp;
                var description = weatherData.weather[0].description;
                res.write("<h1 style='text-align:center'>Weather App</h1>");
                res.write("<h4>"+description+" at <span style='font-weight:bold ; color:red'>"+ query+"</span></h4>");
                res.write("<h4> Temperature at <span style='font-weight:bold ; color:red'>"+ query+"</span> is "+temp+" degree kelvin </h4>");
        res.send();
       

});

});

});


app.listen(process.env.PORT || 3000,function(){
        console.log("Server started at port 3000");
});